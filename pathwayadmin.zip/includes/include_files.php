<?session_start();
include_once "./config.php";
include_once "./service_fee_config.inc";
include "./language/home/pathway/".$_SESSION['lang']."_lang.php";?>