<table width="70%" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td align="left" valign="top"><img src="/images/header/admin/banner/ad_01.gif"></td>
	<td align="left" valign="top"><img src="/images/header/admin/banner/ad_02.gif"></td>
	<td align="left" valign="top"><img src="/images/header/admin/banner/ad_03.gif"></td>
</tr>
</table>