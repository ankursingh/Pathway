<?php

$soap_webservice['live']['webservice_url'] = "";
$soap_webservice['test']['webservice_url'] = "";
$active_group = "live";
