<?php
	include("./soapinterface.php");
	$soap=new SoapInterface();

?>
