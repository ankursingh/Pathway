<table cellspacing="0" cellpadding="0" border="0">
<tbody>
<tr>
	<td class="mainside" valign="top"><!--start boxshell_Left_Navigation-->
		<!--start_head_yourgov_closed-->
		<div class="boxshellside">
        	<div class="boxshellside" id="ministry2">
            	<div><img src="/images/menu/top.gif" width="172" border="0" /></div>
              	<div class="boxsmallhead"><a href="/index.php" class="columnnav">Admin Menu</a></div>
			</div>
            <div class="boxshellside" id="ministry1" style="DISPLAY: none">
            <div><img alt="" src="/images/menu/top.gif" border="0" /></div>
            <div class="boxsmallhead"><a href="/index.php" class="columnnav">Admin Menu</a></div>
        </div>
        
		
		<!--end_head_yourgov opened-->
			<!--start boxcontent_yourgov-->
		
			<div class="boxcontent" id="boxcontent1">

				<div id="HighSpeed2">
					<ul>
						<li class="arrow"><span class="moduleHead"><a href="notification.php">Notifications</a></span></li>
					</ul>
				</div>

				<div id="HighSpeed2">
					<ul>
						<li class="arrow"><span class="moduleHead">Manage Search Keywords</span></li>
					</ul>
				</div>
				<div id="highspeed_submenus">
					<ul>
						<li class="arrowin"><a href="./add_keywords.php?condition=Add" class="columnnav"><b>Add Search Keywords</b></a></li>
						<li class="arrowin"><a href="./keywords.php?condition=Modify" class="columnnav"><b>Modify Search Keywords</b></a></li>
						<li class="arrowin"><a href="./keywords.php?condition=Delete" class="columnnav"><b>Delete Search Keywords</b></a></li>
						<li class="arrowin"><a href="./keywords.php?condition=View" class="columnnav"><b>View Search Keywords</b></a></li>
					</ul>
				</div>
				
				
				<div id="HighSpeed4">
					<ul>
						<li class="arrow"><span class="moduleHead">Manage Bonus PINs</span></li>
					</ul>
				</div>
				<div id="highspeed_submenus2">
					<ul>
						<li class="arrowin"><a href="./reward_pins_report.php?condition=Delete" class="columnnav"><b>Delete Reward PINs</b></a></li>
						<li class="arrowin"><a href="./reward_pins_report.php?condition=View" class="columnnav"><b>View Reward PINs</b></a></li>
					</ul>
				</div>
				
				<div id="HighSpeed6">
					<ul>
						<li class="arrow"><span class="moduleHead">Manage News Articles</span></li>
					</ul>
				</div>
				<div id="highspeed_submenus3">
					<ul>
						<li class="arrowin"><a href="./news.php?condition=Add" class="columnnav"><b>Add News Articles</b></a></li>
						<li class="arrowin"><a href="./news_select.php?condition=Delete" class="columnnav"><b>View News Articles</b></a></li>
						<li class="arrowin"><a href="./rssfeed.php?condition=Add" class="columnnav"><b>Add RSS Feed</b></a></li>
						<li class="arrowin"><a href="./rssfeed_select.php?condition=Delete" class="columnnav"><b>View RSS Feed</b></a></li>
						<li class="arrowin"><a href="./general_setup.php" class="columnnav"><b>General Setup</b></a></li>
						<li class="arrowin"><a href="./rss_general_setup.php" class="columnnav"><b>RSS General Setup</b></a></li>
					</ul>
				</div>
				
				<div id="dashboard5">
					<ul>
						<li class="arrow"><span class="moduleHead">Manage Long Distance Rates</span></li>
					</ul>
				</div>
				<div id="dashboard_submenus6">
					<ul>
						<li class="arrowin"><a href="./country.php?condition=Add" class="columnnav"><b>Add Country Data</b></a></li>
						<li class="arrowin"><a href="./country_select.php?condition=Delete" class="columnnav"><b>View Country Data</b></a></li>
						<li class="arrowin"><a href="./city.php?condition=Add" class="columnnav"><b>Add City Data</b></a></li>
						<li class="arrowin"><a href="./modify_city.php?condition=Modify" class="columnnav"><b>Modify City Data</b></a></li>
						<li class="arrowin"><a href="./modify_city.php?condition=Delete" class="columnnav"><b>Delete City Data</b></a></li>
					</ul>
				</div>
			</div>	
			
			<!--end boxcontent_yourgov-->
			<div class="boxsidebtm">&nbsp;</div>
			<!--<div class="sideHeadbtm">&nbsp;</div>-->
		</div>
		<!-- ##################################### End Your Government ##################################### -->
    </td>
</tr>
</tbody>
</table>
