<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<table width="100%" height="42" border="0" align="left" cellpadding="0" cellspacing="0" background="/images/header/base.gif" style="background-repeat:no-repeat">
<tr> 
	<td align="left" valign="top" class="footer1" style="padding-left:25px; padding-top:5px"><a href="<?echo PATHWAY_SITE_URL?>/contactus/index.php" class="footerLink"><?echo SITE_MAP_CONTACTUS?></a> | <a href="<?echo PATHWAY_SITE_URL?>/company/careers.php" class="footerLink"><?echo SITE_MAP_CAREERS?></a> | <a href="<?echo PATHWAY_SITE_URL?>/site_map.php" class="footerLink"><?echo SITE_MAP?></a> | <a href="<?echo PATHWAY_SITE_URL?>/legal_notice.php" class="footerLink"><?echo SITE_MAP_LEGAL_NOTICE?></a> | <a href="<?echo PATHWAY_SITE_URL?>/privacy_policy.php" class="footerLink"><?echo SITE_MAP_PRIVACY_POLICY?></a> | <a href="<?echo PATHWAY_SITE_URL?>/resellers/index.php" class="footerLink"><?echo RESELLERS?></a> | <a href="<?echo PATHWAY_SITE_URL?>/news/rss.xml" class="footerLink" target="_blank"><?echo RSS_FEED?></a></td>
    <td align="right" valign="top" class="footer2" style=" padding-right:25px; padding-top:5px"><?echo COPYRIGHTS." ".date("Y")." | ".PATHWAY_COMMUNICATION;?></td>
</tr>
</table>
<?/*
if (file_exists('../includes/analytics_script.php')) {
	include_once('../includes/analytics_script.php');
}
else if (file_exists('../../includes/analytics_script.php')) {
	include_once('../../includes/analytics_script.php');
}
else {
	include_once('./includes/analytics_script.php');
}*/
?>