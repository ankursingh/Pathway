<?echo phpinfo();?>
